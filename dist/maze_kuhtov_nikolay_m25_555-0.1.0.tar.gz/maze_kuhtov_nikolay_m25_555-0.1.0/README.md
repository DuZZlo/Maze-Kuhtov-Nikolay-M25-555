# Maze-Kuhtov-Nikolay-M25-555

# Virtual Environment
.venv/
